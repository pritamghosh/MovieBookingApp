package pritam.demo;

import java.security.Principal;

import org.springframework.beans.factory.InitializingBean;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;
import org.springframework.security.oauth2.config.annotation.web.configuration.EnableResourceServer;
import org.springframework.security.oauth2.provider.OAuth2Authentication;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import pritam.demo.constants.ApplicationConstant;
import pritam.demo.dao.RoleRepository;
import pritam.demo.util.ApplicationContext;

@SpringBootApplication
public class AuthorizationServerDemoApplication {

	@Autowired
	RoleRepository roleRepo;
	
	public static void main(String[] args) {
		SpringApplication.run(AuthorizationServerDemoApplication.class, args);
	}
	
	@Bean
    InitializingBean populateApplicationConttext() {
        return () -> {
        	ApplicationContext.put(ApplicationConstant.ALL_ROLE,  roleRepo.findAll());
        	ApplicationContext.put(ApplicationConstant.USER_ROLE, roleRepo.findByRole(ApplicationConstant.USER));
          };
       }
	

}
