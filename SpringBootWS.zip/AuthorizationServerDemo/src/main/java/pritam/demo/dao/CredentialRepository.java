package pritam.demo.dao;

import org.springframework.data.jpa.repository.JpaRepository;

import pritam.demo.model.Credential;
import java.lang.String;
import java.util.List;

/**
 * <pre>
 * <b>Description : </b>
 * CredentialRepository.
 * 
 * @version $Revision: 1 $ $Date: Dec 20, 2017 7:31:14 PM $
 * @author $Author: pritam.ghosh $ 
 * </pre>
 */
public interface CredentialRepository extends JpaRepository<Credential, Long> {
List<Credential> findByUsername(String username);
}
