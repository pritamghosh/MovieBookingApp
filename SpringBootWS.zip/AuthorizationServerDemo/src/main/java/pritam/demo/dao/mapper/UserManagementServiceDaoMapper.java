package pritam.demo.dao.mapper;

import java.util.List;
import java.util.stream.Collectors;

import org.springframework.security.core.userdetails.UserDetails;

import  pritam.demo.constants.ApplicationConstant;
import  pritam.demo.dto.UserDto;
import pritam.demo.model.Credential;
import pritam.demo.model.Role;
import pritam.demo.model.User;
import pritam.demo.util.ApplicationContext;

/**
 * <pre>
 * <b>Description : </b>
 * UserManagementServiceDaoMapper.
 * 
 * @version $Revision: 1 $ $Date: Dec 13, 2017 1:17:03 PM $
 * @author $Author: pritam.ghosh $ 
 * </pre>
 */
public class UserManagementServiceDaoMapper {


	/**
	 * <pre>
	 * <b>Description : </b>
	 * mapUserWithCreateUserRequest.
	 * 
	 * &#64;param dto
	 * &#64;return User , null if not found.
	 * </pre>
	 */
	public static User mapUserDAOCreateDTO(UserDto dto) {
		if (dto != null) {
			User user = new User();
			user.setName(dto.getName());
			user.setContact(dto.getContact());
			user.setEmail(dto.getEmail());
			user.setAdsress(dto.getAddress());
			Credential credential = new Credential();
			credential.setUser(user);
			credential.setUsername(dto.getUsername());
			credential.setPassword(dto.getPassword());
			user.setCredential(credential);
			return user;
		}
		return null;
	}

	/**
	 * <pre>
	 * <b>Description : </b>
	 * mapUserDAOWithRequest.
	 * 
	 * &#64;param credential
	 * &#64;return Object , null if not found.
	 * </pre>
	 */
	public static UserDto mapUser(Credential credential) {
		if (credential != null) {
			UserDto dto = new UserDto();
			dto.setUsername(credential.getUsername());
			dto.setPassword(credential.getPassword());
			User user = credential.getUser();
			dto.setAddress(user.getAdsress());
			dto.setContact(user.getContact());
			dto.setEmail(user.getEmail());
			dto.setName(user.getName());
			List<Role> roleList = (List<Role>) ApplicationContext.get(ApplicationConstant.ALL_ROLE);
			if (roleList != null) {
				List<String> list = roleList.stream()
						.filter(role -> role.getPriority() >= credential.getRole().getPriority())
						.map(role -> role.getRole()).collect(Collectors.toList());
				dto.setRoles(list);
			}
			return dto;
		}
		return null;
	}

}
