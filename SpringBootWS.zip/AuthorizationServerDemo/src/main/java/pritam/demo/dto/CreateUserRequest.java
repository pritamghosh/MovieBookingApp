package pritam.demo.dto;

/**
 * <pre>
 * <b>Description : </b>
 * CreateUserRequest.
 * 
 * &#64;version $Revision: 1 $ $Date: Dec 20, 2017 1:03:54 PM $
 * &#64;author $Author: pritam.ghosh $
 * </pre>
 */
public class CreateUserRequest extends UserDto {
	private static final long serialVersionUID = 7222324754301353275L;
	private String role;

	public final String getRole() {
		return role;
	}

	public final void setRole(String role) {
		this.role = role;
	}

}
