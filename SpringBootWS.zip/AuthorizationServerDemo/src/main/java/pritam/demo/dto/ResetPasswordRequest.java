package pritam.demo.dto;

public class ResetPasswordRequest extends CreateUserRequest {

}
