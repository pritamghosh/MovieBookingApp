package pritam.demo.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

/**
 * <pre>
 * <b>Description : </b>
 * Role.
 * 
 * @version $Revision: 1 $ $Date: Dec 20, 2017 11:22:39 AM $
 * @author $Author: pritam.ghosh $ 
 * </pre>
 */
@Entity

@Table(name = "ROLE")
public class Role {
    @Id
    @Column(name = "ROLE_ID")
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Integer id;
    @Column(name = "ROLE_NAME", unique = true)
    private String role;
    @Column(name = "ROLE_PRIORITY", unique = true)
    private int priority;

    public  int getId() {
        return id;
    }

    public  void setId(int id) {
        this.id = id;
    }

    public  String getRole() {
        return role;
    }

    public  void setRole(String role) {
        this.role = role;
    }

    public  int getPriority() {
        return priority;
    }

    public  void setPriority(int priority) {
        this.priority = priority;
    }

}
