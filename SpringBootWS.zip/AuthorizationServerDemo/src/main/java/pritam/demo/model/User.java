package pritam.demo.model;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;


/**
 * <pre>
 * <b>Description : </b>
 * User.
 * 
 * @version $Revision: 1 $ $Date: Dec 20, 2017 11:22:12 AM $
 * @author $Author: pritam.ghosh $ 
 * </pre>
 */
@Entity
@Table(name = "USER")
public class User {
    @Id
    @Column(name = "USER_ID")
    @GeneratedValue(strategy = GenerationType.AUTO)
    private long id;

    @Column(name = "NAME")
    private String Name;

    @Column(name = "EMAIL", unique = true)
    private String email;

    @Column(name = "CONTACT", unique = true)
    private String contact;
    
    @Column(name = "ADDRESS")
    private String adsress;
    
    @OneToOne(cascade = CascadeType.ALL)
    @JoinColumn(name = "CREDENTIAL_ID")
    private Credential credential;

    public  long getId() {
        return id;
    }

    public  void setId(long id) {
        this.id = id;
    }

    public  String getName() {
        return Name;
    }

    public  void setName(String name) {
        Name = name;
    }

    public  String getEmail() {
        return email;
    }

    public  void setEmail(String email) {
        this.email = email;
    }

    public  String getContact() {
        return contact;
    }

    public  void setContact(String contact) {
        this.contact = contact;
    }

    public  Credential getCredential() {
        return credential;
    }

    public  void setCredential(Credential credential) {
        this.credential = credential;
    }

    public  String getAdsress() {
        return adsress;
    }

    public  void setAdsress(String adsress) {
        this.adsress = adsress;
    }
    
    

}
