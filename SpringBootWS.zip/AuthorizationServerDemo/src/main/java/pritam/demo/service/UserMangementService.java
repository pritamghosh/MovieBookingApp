package pritam.demo.service;

import javax.validation.Valid;

import pritam.demo.dto.UpdatePasswordRequest;
import pritam.demo.dto.UserDto;

public interface UserMangementService {

	boolean updatePassword(String username, @Valid UpdatePasswordRequest request);

	UserDto updateUser(String username, @Valid UserDto request);

	boolean createUser(@Valid UserDto request);

}
