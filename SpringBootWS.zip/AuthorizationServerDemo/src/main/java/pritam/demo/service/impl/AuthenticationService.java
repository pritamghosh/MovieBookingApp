package pritam.demo.service.impl;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;

import pritam.demo.dao.AuthenticationMangerDao;
import pritam.demo.dao.mapper.UserManagementServiceDaoMapper;
import pritam.demo.model.Credential;

/**
 * <pre>
 * <b>Description : </b>
 * AuthenticationService.
 * 
 * &#64;version $Revision: 1 $ $Date: Dec 4, 2017 4:17:36 PM $
 * &#64;author $Author: pritam.ghosh $
 * </pre>
 */
@Service
public class AuthenticationService implements UserDetailsService {

	private static final Logger LOGGER = LoggerFactory.getLogger(AuthenticationService.class);
	@Autowired
	AuthenticationMangerDao authenticationMangerDao;

	/**
	 * <pre>
	 * <b>Description : </b> loadUserByUsername.
	 * 
	 * @param arg0
	 * @return
	 * @throws UsernameNotFoundException
	 *             AuthenticationService , null if not found
	 */
	@Override
	public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
		List<Credential> list = authenticationMangerDao.findByUsername(username);
		if (list != null && !list.isEmpty()) {

			Credential credential = list.get(0);
			return UserManagementServiceDaoMapper.mapUser(credential);
		}
		LOGGER.warn("no user forn with username : " + username);
		throw new UsernameNotFoundException("no user forn with username : " + username);
	}

}
