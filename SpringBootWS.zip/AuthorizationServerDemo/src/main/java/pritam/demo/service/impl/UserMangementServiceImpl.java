package pritam.demo.service.impl;

import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Sort;
import org.springframework.security.crypto.bcrypt.BCrypt;
import org.springframework.stereotype.Service;

import pritam.demo.constants.ApplicationConstant;
import pritam.demo.dao.CredentialRepository;
import pritam.demo.dao.UserRepository;
import pritam.demo.dao.mapper.UserManagementServiceDaoMapper;
import pritam.demo.dto.UpdatePasswordRequest;
import pritam.demo.dto.UserDto;
import pritam.demo.exceptions.ApplicationCustomException;
import pritam.demo.exceptions.BadCredentialException;
import pritam.demo.exceptions.ErrorResponse;
import pritam.demo.model.Credential;
import pritam.demo.model.Role;
import pritam.demo.model.User;
import pritam.demo.service.UserMangementService;
import pritam.demo.util.ApplicationContext;

@Service
public class UserMangementServiceImpl implements UserMangementService {

	@Autowired
	CredentialRepository credRepo;

	@Autowired
	UserRepository userRepo;

	@Override
	public boolean updatePassword(String username, @Valid UpdatePasswordRequest request) {
		if (request.getUsername().equalsIgnoreCase(username)) {
			List<Credential> findByUsername = credRepo.findByUsername(username);
			if (findByUsername != null) {
				for (Credential credential : findByUsername) {
					BCrypt.checkpw(request.getOldPassword(), credential.getPassword());
					if (BCrypt.checkpw(request.getOldPassword(), credential.getPassword())) {
						credential.setPassword(BCrypt.hashpw(request.getNewPassword(), BCrypt.gensalt(4)));
						credRepo.saveAndFlush(credential);
						return true;
					}
				}
			}
		}
		throw new BadCredentialException();
	}

	@Override
	public UserDto updateUser(String username, @Valid UserDto request) {
		if (request.getUsername().equalsIgnoreCase(username)) {
			List<Credential> findByUsername = credRepo.findByUsername(username);
			if (findByUsername != null) {
				for (Credential credential : findByUsername) {
					User userInDb = credential.getUser();
					if(request.getAddress()!=null) {
						userInDb.setAdsress(request.getAddress());
					}
					if(request.getEmail()!=null) {
						userInDb.setEmail(request.getEmail());
					}
					if(request.getContact()!=null) {
						userInDb.setContact(request.getContact());
					}
					userRepo.saveAndFlush(userInDb);
				}
			}
		}
		return request;
	}

	@Override
	public boolean createUser(UserDto request) {
		List<Credential> findByUsername = credRepo.findByUsername(request.getUsername());
		if (!findByUsername.isEmpty()) {
			ErrorResponse errorResponse = new ErrorResponse("Username is not available");
			throw new ApplicationCustomException(errorResponse);
		}
		List<User> findByUserInfo = userRepo.findByEmail(request.getEmail());
		if (!findByUserInfo.isEmpty()) {
			ErrorResponse errorResponse = new ErrorResponse("Email is already registered");
			throw new ApplicationCustomException(errorResponse);
		}
		findByUserInfo = userRepo.findByContact(request.getContact());
		if (!findByUserInfo.isEmpty()) {
			ErrorResponse errorResponse = new ErrorResponse("Contact No is already registered");
			throw new ApplicationCustomException(errorResponse);
		}
		request.setPassword(BCrypt.hashpw(request.getPassword(), BCrypt.gensalt(4)));
		User user = UserManagementServiceDaoMapper.mapUserDAOCreateDTO(request);
		List<Role> defaultRoleList = (List<Role>) ApplicationContext.get(ApplicationConstant.USER_ROLE);
		user.getCredential().setRole(defaultRoleList.get(0));
		userRepo.saveAndFlush(user);
		return true;
	}

}
