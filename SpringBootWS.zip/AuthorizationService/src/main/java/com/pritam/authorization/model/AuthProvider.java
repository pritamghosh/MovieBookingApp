package com.pritam.authorization.model;

public enum AuthProvider {
	LOCAL, FACEBOOK, GOOGLE;
}
