package com.pritam.authorization.model;

public enum RoleType {
	ADMIN, AGENT, CUSTOMER, USER;
}
