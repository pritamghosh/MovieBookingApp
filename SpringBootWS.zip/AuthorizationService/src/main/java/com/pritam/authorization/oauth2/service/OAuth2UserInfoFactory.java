package com.pritam.authorization.oauth2.service;

import java.util.Map;

import com.pritam.authorization.dto.FacebookOAuth2UserInfo;
import com.pritam.authorization.dto.GoogleOAuth2UserInfo;
import com.pritam.authorization.dto.OAuth2UserInfo;
import com.pritam.authorization.model.AuthProvider;

public class OAuth2UserInfoFactory {

	public static OAuth2UserInfo getOAuth2UserInfo(String registrationId, Map<String, Object> attributes) {
		AuthProvider authProvider = AuthProvider.valueOf(registrationId.toUpperCase());
		OAuth2UserInfo oAuth2UserInfo = null ;
		switch (authProvider) {
		case GOOGLE:
			oAuth2UserInfo= new GoogleOAuth2UserInfo(attributes);
			break;
		case FACEBOOK:
			oAuth2UserInfo= new FacebookOAuth2UserInfo(attributes);
			break;
		case LOCAL:
			//TODO: check
			break;
		default:
			break;
		}
		return oAuth2UserInfo;
	}
}
