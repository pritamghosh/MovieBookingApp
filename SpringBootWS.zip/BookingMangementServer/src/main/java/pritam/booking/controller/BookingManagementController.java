package pritam.booking.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.oauth2.provider.OAuth2Authentication;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import pritam.booking.dto.BookingDto;
import pritam.booking.dto.UserDto;
import pritam.booking.service.BookingManagementService;

/**
 * <pre>
 * <b>Description : </b>
 * BookingManagementController.
 * 
 * &#64;version $Revision: 1 $ $Date: Dec 20, 2017 6:30:52 PM $
 * &#64;author $Author: pritam.ghosh $
 * </pre>
 */
@RestController
@RequestMapping(value = "/booking")
public class BookingManagementController {
	@Autowired
	BookingManagementService service;

	@PostMapping(value = "/new")
	public @ResponseBody BookingDto newBooking(@RequestBody BookingDto request) {
		return service.addBooking(request);
	}

	@GetMapping(value = "/cancle")
	public @ResponseBody boolean cancleBooking(@RequestParam("id") long id) {
		return service.cancleBooking(id);
	}

	@GetMapping(value = "/get")
	@PreAuthorize("hasAuthority('USER')")
	public @ResponseBody List<BookingDto> geBookingByUsername(OAuth2Authentication user) {
		String username = ((UserDto) user.getPrincipal()).getUsername();
		return service.getBookings(username);
	}

	@GetMapping(value = "/all")
	@PreAuthorize("hasAuthority('ADMIN')")
	public @ResponseBody List<BookingDto> geBooking() {
		return service.getAllBookings();
	}

}
