package pritam.booking.dao;

import org.springframework.data.jpa.repository.JpaRepository;

import pritam.booking.model.Booking;
import java.lang.String;
import java.util.List;

/**
 * <pre>
 * <b>Description : </b>
 * BookingRepository.
 * 
 * @version $Revision: 1 $ $Date: Dec 20, 2017 6:55:42 PM $
 * @author $Author: pritam.ghosh $ 
 * </pre>
 */
public interface BookingRepository extends JpaRepository<Booking, Long> {
	List<Booking> findByUsername(String username);
}
