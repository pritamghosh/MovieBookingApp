package pritam.booking.dao;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import pritam.booking.model.Restaurant;

/**
 * <pre>
 * <b>Description : </b>
 * RestaurantRepository.
 * 
 * @version $Revision: 1 $ $Date: Dec 20, 2017 5:09:40 PM $
 * @author $Author: pritam.ghosh $ 
 * </pre>
 */
public interface RestaurantRepository extends JpaRepository<Restaurant, Long> {
	
	@Query("select r from Restaurant r where r.name like %?1 or r.address like %?1")
	List<Restaurant> search(String key);
}
