package pritam.booking.dao;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import pritam.booking.model.RestaurantTable;

/**
 * <pre>
 * <b>Description : </b>
 * SelectedTableRepository.
 * 
 * @version $Revision: 1 $ $Date: Dec 20, 2017 6:59:42 PM $
 * @author $Author: pritam.ghosh $ 
 * </pre>
 */
public interface RestaurantTableRepository extends JpaRepository<RestaurantTable, Long> {
	List<RestaurantTable> findAllById(List<Long> tableIds);
}
