package pritam.booking.dao;

import java.util.Date;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import pritam.booking.model.SelectedTable;

/**
 * <pre>
 * <b>Description : </b>
 * SelectedTableRepository.
 * 
 * @version $Revision: 1 $ $Date: Dec 20, 2017 6:59:42 PM $
 * @author $Author: pritam.ghosh $ 
 * </pre>
 */
public interface SelectedTableRepository extends JpaRepository<SelectedTable, Long> {
	@Query("SELECT SUM(s.noOfTables) FROM SelectedTable s WHERE s.table.id =:tableId and s.booking.reservationDate =:queryDate")
	Integer fetchReservedCount(@Param("tableId") Long tableId,@Param("queryDate") Date queryDate);
}
