package pritam.booking.dto;

import java.util.Date;
import java.util.List;

/**
 * <pre>
 * <b>Description : </b>
 * BookingDto.
 * 
 * @version $Revision: 1 $ $Date: Dec 20, 2017 6:32:31 PM $
 * @author $Author: pritam.ghosh $ 
 * </pre>
 */
public class BookingDto {
    private long id;
    private Date bookingDate = new Date();
    private RestaurantDto restaurant;
    private List<SelectedTableDTO> bookedTable;
    private double totalPrice;
    private String userName;
    private Date reservationDate = new Date();
    private BookingStatus bookingStatus;
    public final long getId() {
        return id;
    }
    public final void setId(long id) {
        this.id = id;
    }
    public final Date getBookingDate() {
        return bookingDate;
    }
    public final void setBookingDate(Date bookingDate) {
        this.bookingDate = bookingDate;
    }
    
	public final List<SelectedTableDTO> getBookedTable() {
        return bookedTable;
    }
    public final void setBookedTable(List<SelectedTableDTO> bookedTable) {
        this.bookedTable = bookedTable;
    }
    public final double getTotalPrice() {
        return totalPrice;
    }
    public final void setTotalPrice(double totalPrice) {
        this.totalPrice = totalPrice;
    }
    public final String getUserName() {
        return userName;
    }
    public final void setUserName(String userName) {
        this.userName = userName;
    }
	public Date getReservationDate() {
		return reservationDate;
	}
	public void setReservationDate(Date reservationDate) {
		this.reservationDate = reservationDate;
	}
	public final BookingStatus getBookingStatus() {
		return bookingStatus;
	}
	public final void setBookingStatus(BookingStatus bookingStatus) {
		this.bookingStatus = bookingStatus;
	}
	public final RestaurantDto getRestaurant() {
		return restaurant;
	}
	public final void setRestaurant(RestaurantDto restaurant) {
		this.restaurant = restaurant;
	}

	
    
}
