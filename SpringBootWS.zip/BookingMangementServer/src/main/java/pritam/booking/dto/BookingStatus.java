package pritam.booking.dto;

public enum BookingStatus {
	CONF("Confirmed"), CNXL("Cancelled"), CMPL("Completed"), EXP("Expired");

	private String value;

	private BookingStatus(String value) {
		this.value = value;
	}

	public final String getValue() {
		return value;
	}
	
	public static BookingStatus get(String valueParam) {
		for (BookingStatus bookingStatus : BookingStatus.values()) {
			if(bookingStatus.value.equalsIgnoreCase(valueParam))
				return bookingStatus;
		}
		return null;
	}

}
