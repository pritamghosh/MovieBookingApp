package pritam.booking.dto;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

/**
 * <pre>
 * <b>Description : </b>
 * RestaurantDto.
 * 
 * @version $Revision: 1 $ $Date: Dec 20, 2017 4:56:59 PM $
 * @author $Author: pritam.ghosh $ 
 * </pre>
 */
public class RestaurantDto {
    private long id;
    private String name;
    private String address;
    private String contact;
    public final long getId() {
        return id;
    }
    public final void setId(long id) {
        this.id = id;
    }
    public final String getName() {
        return name;
    }
    public final void setName(String name) {
        this.name = name;
    }
    public final String getAddress() {
        return address;
    }
    public final void setAddress(String address) {
        this.address = address;
    }
    public final String getContact() {
        return contact;
    }
    public final void setContact(String contact) {
        this.contact = contact;
    }
    
}
