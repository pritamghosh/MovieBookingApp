package pritam.booking.dto;

/**
 * <pre>
 * <b>Description : </b>
 * SelectedTableDTO.
 * 
 * @version $Revision: 1 $ $Date: Dec 20, 2017 6:40:54 PM $
 * @author $Author: pritam.ghosh $ 
 * </pre>
 */
public class SelectedTableDTO {
    private long id;
    private long tableId;
    private int noOfTables;
    public final long getId() {
        return id;
    }
    public final void setId(long id) {
        this.id = id;
    }
    
    public final long getTableId() {
		return tableId;
	}
	public final void setTableId(long tableId) {
		this.tableId = tableId;
	}
	public final int getNoOfTables() {
        return noOfTables;
    }
    public final void setNoOfTables(int noOfTables) {
        this.noOfTables = noOfTables;
    }
    
    

}
