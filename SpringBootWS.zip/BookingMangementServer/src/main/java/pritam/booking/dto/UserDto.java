package pritam.booking.dto;

import java.io.Serializable;
import java.util.Collection;
import java.util.List;
import java.util.stream.Collectors;

import org.springframework.security.core.CredentialsContainer;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.UserDetails;

/**
 * <pre>
 * <b>Description : </b>
 * CreateUserRequest.
 * 
 * &#64;version $Revision: 1 $ $Date: Dec 20, 2017 1:03:54 PM $
 * &#64;author $Author: pritam.ghosh $
 * </pre>
 */
public class UserDto  implements UserDetails,CredentialsContainer, Serializable {

	private static final long serialVersionUID = 5254441590605994962L;
	private String password;


	

    private String name;
    private String email;
    private String contact;
    private String gender;
    private List<String> roles;
    private String username;
    private String address;
    
    /**
     * <pre>
     * <b>Description : </b>
     * getAuthorities.
     * 
     * @return  UserDetailsCustom , null if not found
     */
    @Override
	public Collection<? extends GrantedAuthority> getAuthorities() {
		List<GrantedAuthority> authorities = getRoles().parallelStream()
				.map(role -> new SimpleGrantedAuthority(role)).collect(Collectors.toList());
		return authorities;
	}
    @Override
    public final String getPassword() {
    	return password;
    }
    
    public final void setPassword(String password) {
    	this.password = password;
    }
    
    public final String getAddress() {
		return address;
	}
	public final void setAddress(String address) {
		this.address = address;
	}
	public final String getName() {
        return name;
    }
    public final void setName(String name) {
        this.name = name;
    }
    public final String getEmail() {
        return email;
    }
    public final void setEmail(String email) {
        this.email = email;
    }
    public final String getContact() {
        return contact;
    }
    public final void setContact(String contact) {
        this.contact = contact;
    }
    public final String getGender() {
        return gender;
    }
    public final void setGender(String gender) {
        this.gender = gender;
    }
    
    public final List<String> getRoles() {
        return roles;
    }
    public final void setRoles(List<String> roles) {
        this.roles = roles;
    }
    @Override
    public final String getUsername() {
        return username;
    }
    public final void setUsername(String username) {
        this.username = username;
    }

	@Override
	public void eraseCredentials() {
		this.password=null;
		
	}

	@Override
	public boolean isAccountNonExpired() {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean isAccountNonLocked() {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean isCredentialsNonExpired() {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean isEnabled() {
		// TODO Auto-generated method stub
		return false;
	}
    

	

}
