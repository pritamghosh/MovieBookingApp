package pritam.booking.mapper;

import java.util.ArrayList;
import java.util.Set;

import pritam.booking.dto.BookingDto;
import pritam.booking.dto.BookingStatus;
import pritam.booking.dto.RestaurantDto;
import pritam.booking.dto.SelectedTableDTO;
import pritam.booking.model.Booking;
import pritam.booking.model.Restaurant;
import pritam.booking.model.SelectedTable;

public class BookingServiceMapper {
public static BookingDto mapBooking(Booking dao) {
	if(dao!=null) {
		BookingDto dto = new BookingDto();
		dto.setBookingDate(dao.getBookingDate());
		dto.setReservationDate(dao.getReservationDate());
		dto.setBookingStatus(BookingStatus.get(dao.getStatus()));
		dto.setId(dao.getId());
		dto.setTotalPrice(dao.getTotalPrice());
		dto.setUserName(dao.getUsername());
		RestaurantDto restaurant = new RestaurantDto();
		dto.setRestaurant(restaurant);
		Restaurant restaurantDao = dao.getRestaurant();
		restaurant.setAddress(restaurantDao.getAddress());
		restaurant.setContact(restaurantDao.getContact());
		restaurant.setName(restaurantDao.getName());
		restaurant.setId(restaurantDao.getId());
		Set<SelectedTable> bookedTable = dao.getBookedTable();
		ArrayList<SelectedTableDTO> bookedTableDtoList = new ArrayList<>();
		dto.setBookedTable(bookedTableDtoList);
		for (SelectedTable selectedTable : bookedTable) {
			SelectedTableDTO tableDto = new SelectedTableDTO();
			bookedTableDtoList.add(tableDto);
			tableDto.setId(selectedTable.getId());
			tableDto.setNoOfTables(selectedTable.getNoOfTables());
		}
		return dto;
		
	}
	return null;
}
}
