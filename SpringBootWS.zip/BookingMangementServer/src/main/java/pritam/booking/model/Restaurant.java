package pritam.booking.model;

import java.util.Collection;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;

/**
 * <pre>
 * <b>Description : </b>
 * Restaurant.
 * 
 * @version $Revision: 1 $ $Date: Dec 20, 2017 11:21:17 AM $
 * @author $Author: pritam.ghosh $ 
 * </pre>
 */
@Entity
@Table(name = "RESTAURANT")
public class Restaurant {
    @Id
    @Column(name = "RESTAURANT_ID")
    @GeneratedValue(strategy = GenerationType.AUTO)
    private long id;

    @Column(name = "RESTAURANT_NAME", nullable = false)
    private String name;
    @Column(name = "RESTAURANT_ADDRESS", nullable = false)
    private String address;
    @Column(name = "RESTAURANT_CONTACT", nullable = false)
    private String contact;
    @Column(name = "RATING")
    private double ratingAvg;
    @Column(name = "NO_OF_RATERS")
    private int noOfRaters;
    @OneToMany(cascade = { CascadeType.PERSIST, CascadeType.MERGE,
            CascadeType.REMOVE }, mappedBy = "restaurant", fetch = FetchType.LAZY)
    private Collection<RestaurantTable> tables;
    @OneToMany(cascade = { CascadeType.PERSIST, CascadeType.MERGE,
            CascadeType.REMOVE }, mappedBy = "restaurant", fetch = FetchType.LAZY)
    private Collection<Menu> menus;
    
    
    public Collection<Menu> getMenus() {
		return menus;
	}
	public void setMenus(Collection<Menu> menus) {
		this.menus = menus;
	}
	public final long getId() {
        return id;
    }
    public final void setId(long id) {
        this.id = id;
    }
    public final String getName() {
        return name;
    }
    public final void setName(String name) {
        this.name = name;
    }
    public final String getAddress() {
        return address;
    }
    public final void setAddress(String address) {
        this.address = address;
    }
    public final String getContact() {
        return contact;
    }
    public final void setContact(String contact) {
        this.contact = contact;
    }
    public final double getRatingAvg() {
        return ratingAvg;
    }
    public final void setRatingAvg(double ratingAvg) {
        this.ratingAvg = ratingAvg;
    }
    public final int getNoOfRaters() {
        return noOfRaters;
    }
    public final void setNoOfRaters(int noOfRaters) {
        this.noOfRaters = noOfRaters;
    }
    public final Collection<RestaurantTable> getTables() {
        return tables;
    }
    public final void setTables(Collection<RestaurantTable> tables) {
        this.tables = tables;
    }
    
    

}
