package pritam.booking.service;

import java.util.List;

import pritam.booking.dto.BookingDto;

/**
 * <pre>
 * <b>Description : </b>
 * BookingManagementService.
 * 
 * @version $Revision: 1 $ $Date: Dec 20, 2017 6:31:52 PM $
 * @author $Author: pritam.ghosh $ 
 * </pre>
 */
public interface BookingManagementService {

    /**
     * <pre>
     * <b>Description : </b>
     * addBooking.
     * 
     * @param request
     * @return boolean , null if not found.
     * </pre>
     */
	BookingDto addBooking(BookingDto request);

	List<BookingDto> getBookings(String username);
	
	List<BookingDto> getAllBookings();

	boolean cancleBooking(long id);

}
