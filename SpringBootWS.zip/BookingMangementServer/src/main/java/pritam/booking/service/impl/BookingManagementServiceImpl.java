package pritam.booking.service.impl;

import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.ldap.embedded.EmbeddedLdapProperties.Credential;
import org.springframework.stereotype.Service;

import pritam.booking.dao.BookingRepository;
import pritam.booking.dao.RestaurantRepository;
import pritam.booking.dao.RestaurantTableRepository;
import pritam.booking.dao.SelectedTableRepository;
import pritam.booking.dto.BookingDto;
import pritam.booking.dto.BookingStatus;
import pritam.booking.dto.SelectedTableDTO;
import pritam.booking.exceptions.ApplicationCustomException;
import pritam.booking.exceptions.ErrorResponse;
import pritam.booking.mapper.BookingServiceMapper;
import pritam.booking.model.Booking;
import pritam.booking.model.Restaurant;
import pritam.booking.model.RestaurantTable;
import pritam.booking.model.SelectedTable;
import pritam.booking.service.BookingManagementService;

/**
 * <pre>
 * <b>Description : </b>
 * BookingManagementServiceImpl.
 * 
 * &#64;version $Revision: 1 $ $Date: Dec 20, 2017 6:51:21 PM $
 * &#64;author $Author: pritam.ghosh $
 * </pre>
 */
@Service
public class BookingManagementServiceImpl implements BookingManagementService {

	@Autowired
	BookingRepository bookingRepository;

	@Autowired
	RestaurantTableRepository restaurantTableRepository;
	@Autowired
	SelectedTableRepository selectedTableRepository;

	/**
	 * <pre>
	 * <b>Description : </b> addBooking.
	 * 
	 * @param request
	 * @return BookingManagementService , null if not found
	 */
	@Override
	public BookingDto addBooking(BookingDto request) {

		Booking bookingDbRequest = new Booking();
		bookingDbRequest.setBookingDate(new Date());
		HashSet<SelectedTable> bookedTable = new HashSet<SelectedTable>();
		bookingDbRequest.setBookedTable(bookedTable);
		bookingDbRequest.setReservationDate(request.getReservationDate());
		double totalPrice = 0;

		List<Long> tableIds = request.getBookedTable().stream().map(selectedTable -> selectedTable.getTableId())
				.collect(Collectors.toList());
		List<RestaurantTable> fetcehedTables = restaurantTableRepository.findAllById(tableIds);
		Map<Long, Integer> reservedCountMap = new HashMap<>();
		for (Long id : tableIds) {
			Integer reservedCount = selectedTableRepository.fetchReservedCount(id, request.getReservationDate());
			reservedCountMap.put(id, reservedCount != null ? reservedCount : 0);
		}
		for (RestaurantTable fetcedtable : fetcehedTables) {
			for (SelectedTableDTO table : request.getBookedTable()) {
				int resCount = reservedCountMap.get(fetcedtable.getId());
				if (fetcedtable.getId() == table.getTableId()
						&& fetcedtable.getTotalNoOfTables() - resCount >= table.getNoOfTables()) {
					SelectedTable selectedTable = new SelectedTable();
					selectedTable.setNoOfTables(table.getNoOfTables());
					RestaurantTable restaurantTable = new RestaurantTable();
					restaurantTable.setId(table.getTableId());
					selectedTable.setTable(restaurantTable);
					selectedTable.setBooking(bookingDbRequest);
					bookedTable.add(selectedTable);
					totalPrice = totalPrice + (fetcedtable.getChargesPerTable() * table.getNoOfTables());
				} else {
					throw new ApplicationCustomException(
							new ErrorResponse("SEATS ARE NOT AVAILABLE OR ALREADY BOOKED"));
				}
			}
		}
		Restaurant restaurant = new Restaurant();
		restaurant.setId(request.getRestaurant().getId());
		bookingDbRequest.setRestaurant(restaurant);
		bookingDbRequest.setUsername(request.getUserName());
		bookingDbRequest.setTotalPrice(totalPrice);
		Booking response = bookingRepository.save(bookingDbRequest);
		return BookingServiceMapper.mapBooking(response);
	}


	@Override
	public boolean cancleBooking(long id) {
		Booking booking = bookingRepository.findById(id).get();
		if (booking!=null) {
			booking.setStatus(BookingStatus.CNXL.getValue());
			bookingRepository.save(booking);
			return true;
		}
		return false;
	}


	@Override
	public List<BookingDto> getBookings(String username) {
		List<Booking> findByUsername = bookingRepository.findByUsername(username);
		List<BookingDto> response = findByUsername.stream().map((bookingInDb) -> BookingServiceMapper.mapBooking(bookingInDb)).collect(Collectors.toList());
		return response;
	}


	@Override
	public List<BookingDto> getAllBookings() {
		List<Booking> findByUsername = bookingRepository.findAll();
		List<BookingDto> response = findByUsername.stream().map((bookingInDb) -> BookingServiceMapper.mapBooking(bookingInDb)).collect(Collectors.toList());
		return response;
	}

}
