package pritam.demo;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.config.annotation.method.configuration.EnableGlobalMethodSecurity;
import org.springframework.security.oauth2.client.OAuth2ClientContext;
import org.springframework.security.oauth2.config.annotation.web.configuration.EnableResourceServer;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

@EnableResourceServer
@SpringBootApplication
@RestController

@EnableGlobalMethodSecurity(prePostEnabled = true)
public class ResourceServerDemoApplication {

	public static void main(String[] args) {
		SpringApplication.run(ResourceServerDemoApplication.class, args);
	}
	
	@GetMapping(value="/admin")
	@PreAuthorize("hasAuthority('ADMIN')")
	public String admin() {
		
		return "success";
	}

	@GetMapping(value="/user")
	@PreAuthorize("hasAuthority('USER')")
	public String user() {
		
		return "user";
	}
	
	@GetMapping(value="/test")
	@PreAuthorize("hasAuthority('test')")
	public String test() {
		
		return "test";
	}

}
