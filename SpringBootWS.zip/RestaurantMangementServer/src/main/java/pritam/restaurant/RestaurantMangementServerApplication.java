package pritam.restaurant;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RestaurantMangementServerApplication {

	public static void main(String[] args) {
		SpringApplication.run(RestaurantMangementServerApplication.class, args);
	}

}
