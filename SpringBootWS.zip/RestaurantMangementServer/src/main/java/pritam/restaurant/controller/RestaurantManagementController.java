package pritam.restaurant.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import pritam.restaurant.dto.RestaurantDto;
import pritam.restaurant.service.RestaurantManagementService;

/**
 * <pre>
 * <b>Description : </b>
 * RestaurantController.
 * 
 * @version $Revision: 1 $ $Date: Dec 20, 2017 5:00:48 PM $
 * @author $Author: pritam.ghosh $ 
 * </pre>
 */
@RestController
@RequestMapping(value = "/restaurant")
public class RestaurantManagementController {
    @Autowired
    RestaurantManagementService service;

    @GetMapping(value = "/all")
    public @ResponseBody List<RestaurantDto> getAllRestaurant() {
        return service.getAllRestaurant();
    }
    
    @GetMapping(value = "/search")
    public @ResponseBody List<RestaurantDto> searchRestaurant(@RequestParam("key") String key) {
        return service.searchRestaurant(key);
    }
    
    @GetMapping(value = "/fetchRestaurant")
    public @ResponseBody RestaurantDto getRestaurant(@RequestParam("id") long restaurantId,@RequestParam("queryDate") String queryDate) {
        return service.getRestaurant(restaurantId,queryDate);
    }
    @PostMapping(value = "/add")
	@PreAuthorize("hasAuthority('ADMIN')")
    public @ResponseBody RestaurantDto addRestaurant(@RequestBody RestaurantDto request) {
        return service.addRestaurant(request);
    }

    @PostMapping(value = "/modify")	
	@PreAuthorize("hasAuthority('ADMIN')")
    public @ResponseBody RestaurantDto modifyRestaurant(@RequestBody RestaurantDto request) {
        return service.addRestaurant(request);
    }

    @DeleteMapping(value = "/delete")
	@PreAuthorize("hasAuthority('ADMIN')")
    public @ResponseBody boolean deleteRestaurant(@RequestBody RestaurantDto request) {
        return service.deleteRestaurant(request);
    }
}
