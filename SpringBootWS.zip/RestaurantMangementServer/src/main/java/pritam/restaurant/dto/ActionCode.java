package pritam.restaurant.dto;

public enum ActionCode {
	ADD, UPDATE, DELETE;
}
