package pritam.restaurant.dto;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

/**
 * <pre>
 * <b>Description : </b>
 * RestaurantDto.
 * 
 * @version $Revision: 1 $ $Date: Dec 20, 2017 4:56:59 PM $
 * @author $Author: pritam.ghosh $ 
 * </pre>
 */
public class RestaurantDto {
    private long id;
    private String name;
    private String address;
    private String contact;
    private double ratingAvg;
    private int noOfRaters;
    private Date queryDate = new Date();
    private ActionCode actionCode;
    private List<RestaurantTableDto> tables = new ArrayList<RestaurantTableDto>();
    public final long getId() {
        return id;
    }
    public final void setId(long id) {
        this.id = id;
    }
    public final String getName() {
        return name;
    }
    public final void setName(String name) {
        this.name = name;
    }
    public final String getAddress() {
        return address;
    }
    public final void setAddress(String address) {
        this.address = address;
    }
    public final String getContact() {
        return contact;
    }
    public final void setContact(String contact) {
        this.contact = contact;
    }
    public final double getRatingAvg() {
        return ratingAvg;
    }
    public final void setRatingAvg(double ratingAvg) {
        this.ratingAvg = ratingAvg;
    }
    public final int getNoOfRaters() {
        return noOfRaters;
    }
    public final void setNoOfRaters(int noOfRaters) {
        this.noOfRaters = noOfRaters;
    }
    public final List<RestaurantTableDto> getTables() {
        return tables;
    }
    public final void setTables(List<RestaurantTableDto> tables) {
        this.tables = tables;
    }
    
    public final void addTables(RestaurantTableDto table) {
        this.tables.add(table);
    }
	public Date getQueryDate() {
		return queryDate;
	}
	public void setQueryDate(Date queryDate) {
		this.queryDate = queryDate;
	}
	public final ActionCode getActionCode() {
		return actionCode;
	}
	public final void setActionCode(ActionCode actionCode) {
		this.actionCode = actionCode;
	}
    
}
