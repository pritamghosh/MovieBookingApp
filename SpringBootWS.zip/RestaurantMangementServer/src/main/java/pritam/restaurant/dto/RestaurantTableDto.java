package pritam.restaurant.dto;

/**
 * <pre>
 * <b>Description : </b>
 * RestaurantTableDto.
 * 
 * @version $Revision: 1 $ $Date: Dec 20, 2017 4:57:53 PM $
 * @author $Author: pritam.ghosh $ 
 * </pre>
 */
public class RestaurantTableDto {
    private long id;
    private int seatingCapacity;
    private int totalNoOfTables;
    private int avaiableNoOfTables;
    public int noOfSelectedTables;
    private double chargesPerTable;
    private ActionCode actionCode;
    public final long getId() {
        return id;
    }
    public final void setId(long id) {
        this.id = id;
    }
    public final int getSeatingCapacity() {
        return seatingCapacity;
    }
    public final void setSeatingCapacity(int seatingCapacity) {
        this.seatingCapacity = seatingCapacity;
    }
    public final int getTotalNoOfTables() {
        return totalNoOfTables;
    }
    public final void setTotalNoOfTables(int totalNoOfTables) {
        this.totalNoOfTables = totalNoOfTables;
    }
    public final int getAvaiableNoOfTables() {
        return avaiableNoOfTables;
    }
    public final void setAvaiableNoOfTables(int avaiableNoOfTables) {
        this.avaiableNoOfTables = avaiableNoOfTables;
    }
    public final double getChargesPerTable() {
        return chargesPerTable;
    }
    public final void setChargesPerTable(double chargesPerTable) {
        this.chargesPerTable = chargesPerTable;
    }
	public int getNoOfSelectedTables() {
		return noOfSelectedTables;
	}
	public void setNoOfSelectedTables(int noOfSelectedTables) {
		this.noOfSelectedTables = noOfSelectedTables;
	}
	public final ActionCode getActionCode() {
		return actionCode;
	}
	public final void setActionCode(ActionCode actionCode) {
		this.actionCode = actionCode;
	}
    
}
