package pritam.restaurant.dto;

/**
 * <pre>
 * <b>Description : </b>
 * SelectedTableDTO.
 * 
 * @version $Revision: 1 $ $Date: Dec 20, 2017 6:40:54 PM $
 * @author $Author: pritam.ghosh $ 
 * </pre>
 */
public class SelectedTableDTO {
    private long id;
    private RestaurantTableDto table;
    private int noOfTables;
    public final long getId() {
        return id;
    }
    public final void setId(long id) {
        this.id = id;
    }
    public final RestaurantTableDto getTable() {
        return table;
    }
    public final void setTable(RestaurantTableDto table) {
        this.table = table;
    }
    public final int getNoOfTables() {
        return noOfTables;
    }
    public final void setNoOfTables(int noOfTables) {
        this.noOfTables = noOfTables;
    }
    
    

}
