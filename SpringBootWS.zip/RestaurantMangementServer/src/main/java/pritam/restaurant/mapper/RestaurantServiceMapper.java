package pritam.restaurant.mapper;

import java.util.ArrayList;
import java.util.List;

import pritam.restaurant.dto.ActionCode;
import pritam.restaurant.dto.RestaurantDto;
import pritam.restaurant.dto.RestaurantTableDto;
import pritam.restaurant.model.Restaurant;
import pritam.restaurant.model.RestaurantTable;

/**
 * <pre>
 * <b>Description : </b>
 * RestaurantServiceDaoMapper.
 * 
 * @version $Revision: 1 $ $Date: Dec 20, 2017 5:11:18 PM $
 * @author $Author: pritam.ghosh $
 * </pre>
 */
public class RestaurantServiceMapper {
	public static Restaurant mapRestaurant(RestaurantDto restaurantDto) {
		if (restaurantDto != null && !restaurantDto.getTables().isEmpty()) {
			Restaurant restaurantDAO = new Restaurant();
			restaurantDAO.setName(restaurantDto.getName());
			restaurantDAO.setAddress(restaurantDto.getAddress());
			restaurantDAO.setId(restaurantDto.getId());
			restaurantDAO.setNoOfRaters(restaurantDto.getNoOfRaters());
			restaurantDAO.setContact(restaurantDto.getContact());
			restaurantDAO.setRatingAvg(restaurantDto.getRatingAvg());
			List<RestaurantTable> daoList = new ArrayList<RestaurantTable>();
			for (RestaurantTableDto restaurantTableDto : restaurantDto.getTables()) {
				RestaurantTable tableDao = mapTable(restaurantTableDto);
				tableDao.setRestaurant(restaurantDAO);
				daoList.add(tableDao);
			}
			restaurantDAO.setTables(daoList);
			return restaurantDAO;
		}
		return null;
	}


	/**
	 * <pre>
	 * <b>Description : </b>
	 * mapRestaurantDAOWithRestaurantDTO.
	 * 
	 * @param restaurant
	 * @return RestaurantDto , null if not found.
	 * </pre>
	 */
	public static RestaurantDto mapRestaurant(Restaurant dao) {
		if (dao != null) {
			RestaurantDto dto = new RestaurantDto();
			dto.setAddress(dao.getAddress());
			dto.setContact(dao.getContact());
			dto.setId(dao.getId());
			dto.setName(dao.getName());
			dto.setNoOfRaters(dao.getNoOfRaters());
			dto.setRatingAvg(dao.getRatingAvg());
			if (dao.getTables() != null && !dao.getTables().isEmpty()) {
				ArrayList<RestaurantTableDto> tables = new ArrayList<>();
				for (RestaurantTable restaurantTabledao : dao.getTables()) {
					tables.add(mapTable(restaurantTabledao));

				}
				dto.setTables(tables);
			}
			return dto;
		}
		return null;
	}

	/**
	 * <pre>
	 * <b>Description : </b>
	 * mapTableDAOWithDTO.
	 * 
	 * @param restaurantTableDto void , null if not found.
	 * </pre>
	 * 
	 * @return
	 */
	public static RestaurantTableDto mapTable(RestaurantTable dao) {
		if (dao != null) {
			RestaurantTableDto dto = new RestaurantTableDto();
			
			dto.setChargesPerTable(dao.getChargesPerTable());
			dto.setId(dao.getId());
			dto.setSeatingCapacity(dao.getSeatingCapacity());
			dto.setTotalNoOfTables(dao.getTotalNoOfTables());
			return dto;
		}
		return null;
	}
	
	/**
	 * <pre>
	 * <b>Description : </b>
	 * mapTableDAOWithDTO.
	 * 
	 * @param restaurantTableDto void , null if not found.
	 * </pre>
	 * 
	 * @return
	 */
	public static RestaurantTable mapTable(RestaurantTableDto dto) {
		if (dto != null) {
			RestaurantTable dao = new RestaurantTable();
			
			dao.setChargesPerTable(dto.getChargesPerTable());
			dao.setId(dto.getId());
			dao.setSeatingCapacity(dto.getSeatingCapacity());
			dao.setTotalNoOfTables(dto.getTotalNoOfTables());
			return dao;
		}
		return null;
	}
}
