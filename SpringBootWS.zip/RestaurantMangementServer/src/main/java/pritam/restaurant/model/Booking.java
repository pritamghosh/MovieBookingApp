package pritam.restaurant.model;

import java.util.Date;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

/**
 * <pre>
 * <b>Description : </b>
 * Booking.
 * 
 * &#64;version $Revision: 1 $ $Date: Dec 20, 2017 11:21:52 AM $
 * &#64;author $Author: pritam.ghosh $
 * </pre>
 */
@Entity
@Table(name = "BOOKINGS")
public class Booking {
	@Id
	@Column(name = "BOOKING_ID")
	@GeneratedValue(strategy = GenerationType.AUTO)
	private long id;
	
	@Temporal(TemporalType.DATE)
	@Column(name = "RESERVATION_DATE")
	private Date reservationDate;
	
	@Temporal(TemporalType.DATE)
	@Column(name = "BOOKING_DATE")
	private Date bookingDate;
	
	@OneToOne
	@JoinColumn(name = "RESTAURANT_ID")
	private Restaurant restaurant;
	

	@Column(name = "USER_NAME")
	private String username;
	
	@OneToMany(cascade = { CascadeType.ALL }, mappedBy = "booking")
	private Set<SelectedTable> bookedTable;
	
	@OneToMany(cascade = { CascadeType.ALL }, mappedBy = "booking")
	private Set<SelectedMenu> selectedMenu;
	
	@Column(name = "TOTAL_PRICE")
	private double totalPrice;
	
	@Column(name = "BOOKING_STATUS")
	private String status = "NEW";
	
	
	public String getStatus() {
		return status;
	}

	public void setCompleted(String status) {
		this.status = status;
	}

	public final long getId() {
		return id;
	}

	public final void setId(long id) {
		this.id = id;
	}

	public final Date getBookingDate() {
		return bookingDate;
	}

	public final void setBookingDate(Date bookingDate) {
		this.bookingDate = bookingDate;
	}

	public final Restaurant getRestaurant() {
		return restaurant;
	}

	public final void setRestaurant(Restaurant restaurant) {
		this.restaurant = restaurant;
	}

	public final Set<SelectedTable> getBookedTable() {
		return bookedTable;
	}



	public final String getUsername() {
		return username;
	}

	public final void setUsername(String username) {
		this.username = username;
	}

	public final void setBookedTable(Set<SelectedTable> bookedTable) {
		this.bookedTable = bookedTable;
	}

	public final double getTotalPrice() {
		return totalPrice;
	}

	public final void setTotalPrice(double totalPrice) {
		this.totalPrice = totalPrice;
	}

	public Set<SelectedMenu> getSelectedMenu() {
		return selectedMenu;
	}

	public void setSelectedMenu(Set<SelectedMenu> selectedMenu) {
		this.selectedMenu = selectedMenu;
	}

	public Date getReservationDate() {
		return reservationDate;
	}

	public void setReservationDate(Date reservationDate) {
		this.reservationDate = reservationDate;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	
}
