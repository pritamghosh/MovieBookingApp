package pritam.restaurant.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

/**
 * <pre>
 * <b>Description : </b>
 * Table.
 * 
 * @version $Revision: 1 $ $Date: Dec 20, 2017 11:21:40 AM $
 * @author $Author: pritam.ghosh $ 
 * </pre>
 */
@Entity
@Table(name = "RESTAURANT_TABLE")
public class RestaurantTable {
    @Id
    @Column(name = "TABLE_ID")
    @GeneratedValue(strategy = GenerationType.AUTO)
    private long id;
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "RESTAURANT_ID")
    private Restaurant restaurant;
    @Column(name = "SEATING_CAPACITY")
    private int seatingCapacity;
    @Column(name = "TOTAL_NO_OF_TABLES")
    private int totalNoOfTables;
    @Column(name = "CHARGES_PER_TABLE")
    private double chargesPerTable;
    public final long getId() {
        return id;
    }
    public final void setId(long id) {
        this.id = id;
    }
    public final Restaurant getRestaurant() {
        return restaurant;
    }
    public final void setRestaurant(Restaurant restaurant) {
        this.restaurant = restaurant;
    }
    public final int getSeatingCapacity() {
        return seatingCapacity;
    }
    public final void setSeatingCapacity(int seatingCapacity) {
        this.seatingCapacity = seatingCapacity;
    }
    public final int getTotalNoOfTables() {
        return totalNoOfTables;
    }
    public final void setTotalNoOfTables(int totalNoOfTables) {
        this.totalNoOfTables = totalNoOfTables;
    }
    public final double getChargesPerTable() {
        return chargesPerTable;
    }
    public final void setChargesPerTable(double chargesPerTable) {
        this.chargesPerTable = chargesPerTable;
    }
    
}
