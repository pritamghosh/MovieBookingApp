package pritam.restaurant.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToOne;
import javax.persistence.Table;

@Entity
@Table(name = "SELECTED_MENU")
public class SelectedMenu {
	@Id
	@Column(name = "SELECTED_MENU_ID")
	@GeneratedValue(strategy = GenerationType.AUTO)
	private long id;
	@OneToOne
	@JoinColumn(name = "MENU_ID")
	private Menu menu;
	@Column(name = "QUANTITY")
	private int quantityOrdered;
	@ManyToOne
	@JoinColumn(name = "BOOKING_ID")
	private Booking booking;
}
