package pritam.restaurant.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQuery;
import javax.persistence.OneToOne;
import javax.persistence.Table;

/**
 * <pre>
 * <b>Description : </b>
 * BookingTable.
 * 
 * @version $Revision: 1 $ $Date: Dec 20, 2017 12:23:23 PM $
 * @author $Author: pritam.ghosh $ 
 * </pre>
 */
@Entity
@Table(name = "SELECTED_TABLE")
@NamedQuery(name = "SelectedTable.fetchReservedCount",
query = "SELECT SUM(s.noOfTables) FROM SelectedTable s WHERE s.table.id =:tableId and s.booking.reservationDate =:queryDate"
)
public class SelectedTable {
    @Id
    @Column(name = "SELECTED_TABLE_ID")
    @GeneratedValue(strategy = GenerationType.AUTO)
    private long id;
    @OneToOne
    @JoinColumn(name="RESTAURANT_TABLE_ID")
    private RestaurantTable table;
    @Column(name="NO_OF_TABLE_BOOKED")
    private int noOfTables;
    @ManyToOne
    @JoinColumn(name="BOOKING_ID")
    private Booking booking;
    public final long getId() {
        return id;
    }
    public final void setId(long id) {
        this.id = id;
    }
    public final RestaurantTable getTable() {
        return table;
    }
    public final void setTable(RestaurantTable table) {
        this.table = table;
    }
    public final int getNoOfTables() {
        return noOfTables;
    }
    public final void setNoOfTables(int noOfTables) {
        this.noOfTables = noOfTables;
    }
    public final Booking getBooking() {
        return booking;
    }
    public final void setBooking(Booking booking) {
        this.booking = booking;
    }
    
}
