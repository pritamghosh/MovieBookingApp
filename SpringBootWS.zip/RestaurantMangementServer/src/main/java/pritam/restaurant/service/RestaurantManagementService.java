package pritam.restaurant.service;

import java.util.List;

import pritam.restaurant.dto.RestaurantDto;

/**
 * <pre>
 * <b>Description : </b>
 * RestaurantManagementService.
 * 
 * @version $Revision: 1 $ $Date: Dec 20, 2017 5:05:19 PM $
 * @author $Author: pritam.ghosh $ 
 * </pre>
 */
public interface RestaurantManagementService {

    /**
     * <pre>
     * <b>Description : </b>
     * modifyRestaurant.
     * 
     * @param request
     * @return boolean , null if not found.
     * </pre>
     */
	RestaurantDto modifyRestaurant(RestaurantDto request);

    /**
     * <pre>
     * <b>Description : </b>
     * addRestaurant.
     * @param request 
     * 
     * @return boolean , null if not found.
     * </pre>
     */
    RestaurantDto addRestaurant(RestaurantDto request);

    /**
     * <pre>
     * <b>Description : </b>
     * deleteRestaurant.
     * 
     * @param request
     * @return boolean , null if not found.
     * </pre>
     */
    boolean deleteRestaurant(RestaurantDto request);

    /**
     * <pre>
     * <b>Description : </b>
     * deleteRestaurant.
     * 
     * @param id
     * @return boolean , null if not found.
     * </pre>
     */
    boolean deleteRestaurant(long id);

    /**
     * <pre>
     * <b>Description : </b>
     * getAllRestaurant.
     * 
     * @return boolean , null if not found.
     * </pre>
     */
    List<RestaurantDto> getAllRestaurant();

	/**
	 * @param restaurantId
	 * @param queryDate 
	 * @return
	 */
    RestaurantDto getRestaurant(long restaurantId, String queryDateString);

	List<RestaurantDto> searchRestaurant(String key);

}
