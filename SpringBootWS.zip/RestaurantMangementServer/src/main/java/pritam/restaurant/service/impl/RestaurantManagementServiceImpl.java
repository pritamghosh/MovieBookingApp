package pritam.restaurant.service.impl;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import pritam.restaurant.dao.RestaurantRepository;
import pritam.restaurant.dao.RestaurantTableRepository;
import pritam.restaurant.dao.SelectedTableRepository;
import pritam.restaurant.dto.ActionCode;
import pritam.restaurant.dto.RestaurantDto;
import pritam.restaurant.dto.RestaurantTableDto;
import pritam.restaurant.mapper.RestaurantServiceMapper;
import pritam.restaurant.model.Restaurant;
import pritam.restaurant.model.RestaurantTable;
import pritam.restaurant.service.RestaurantManagementService;

/**
 * <pre>
 * <b>Description : </b>
 * RestaurantManagementServiceImpl.
 * 
 * &#64;version $Revision: 1 $ $Date: Dec 20, 2017 5:08:38 PM $
 * &#64;author $Author: pritam.ghosh $
 * </pre>
 */
@Service
public class RestaurantManagementServiceImpl implements RestaurantManagementService {

	@Autowired
	RestaurantRepository restaurantRepo;
	@Autowired
	private SelectedTableRepository selectedTableRepository;
	@Autowired
	private RestaurantTableRepository tableRepo;
	

	/**
	 * <pre>
	 * <b>Description : </b> modifyRestaurant.
	 * 
	 * @param request
	 * @return RestaurantManagementServiceImpl , null if not found
	 */
	@Override
	public RestaurantDto modifyRestaurant(RestaurantDto request) {
		if (ActionCode.UPDATE.equals(request.getActionCode())) {
			Optional<Restaurant> findById = restaurantRepo.findById(request.getId());
			Restaurant restaurantInDb = findById.get();
			if (restaurantInDb != null) {
				if (request.getName() != null)
					restaurantInDb.setName(request.getName());
				if (request.getContact() != null)
					restaurantInDb.setContact(request.getContact());
				if (request.getAddress() != null)
					restaurantInDb.setAddress(request.getAddress());
				Collection<RestaurantTable> tablesInDb = restaurantInDb.getTables();
				request.getTables().forEach(table->{
					if(ActionCode.DELETE.equals(table.getActionCode())) {
						tableRepo.deleteById(table.getId());
					}
					else { 
						tablesInDb.add(RestaurantServiceMapper.mapTable(table));
					}
				});
				restaurantRepo.save(restaurantInDb);
			}
		}
		return null;
	}

	/**
	 * <pre>
	 * <b>Description : </b> addRestaurant.
	 * 
	 * @param request
	 * @return RestaurantManagementServiceImpl , null if not found
	 */
	@Override
	public RestaurantDto addRestaurant(RestaurantDto request) {
		Restaurant restaurantDao = RestaurantServiceMapper.mapRestaurant(request);
		if (restaurantDao != null) {
			Restaurant adedRestaurant = restaurantRepo.save(restaurantDao);
			return RestaurantServiceMapper.mapRestaurant(adedRestaurant);
		}
		return null;
	}

	/**
	 * <pre>
	 * <b>Description : </b> deleteRestaurant.
	 * 
	 * @param request
	 * @return RestaurantManagementServiceImpl , null if not found
	 */
	@Override
	public boolean deleteRestaurant(RestaurantDto request) {
		if (request.getId() != 0) {
			restaurantRepo.deleteById(request.getId());
			return true;
		}
		return false;
	}

	/**
	 * <pre>
	 * <b>Description : </b> deleteRestaurant.
	 * 
	 * @param request
	 * @return RestaurantManagementServiceImpl , null if not found
	 */
	@Override
	public boolean deleteRestaurant(long id) {
		restaurantRepo.deleteById(id);
		return true;
	}

	/**
	 * <pre>
	 * <b>Description : </b> getAllRestaurant.
	 * 
	 * @return RestaurantManagementService , null if not found
	 */
	@Override
	public List<RestaurantDto> getAllRestaurant() {
		List<Restaurant> allRestaurant = restaurantRepo.findAll();
		if (allRestaurant != null && !allRestaurant.isEmpty()) {
			List<RestaurantDto> allDtos = new ArrayList<>();
			for (Restaurant restaurant : allRestaurant) {
				restaurant.getTables();
				allDtos.add(RestaurantServiceMapper.mapRestaurant(restaurant));
			}
			return allDtos;
		}
		return null;
	}

	@Override
	public RestaurantDto getRestaurant(long restaurantId, String queryDateString) {
		Optional<Restaurant> dbResponse = restaurantRepo.findById(restaurantId);
		Restaurant restaurant = dbResponse.get();
		if (restaurant != null && restaurant.getTables() != null) {
			RestaurantDto restaurantDto = RestaurantServiceMapper.mapRestaurant(restaurant);
			Date queryDate = new Date();
			try {
				if (queryDateString != null && !queryDateString.trim().isEmpty()) {
					DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
					queryDate = dateFormat.parse(queryDateString);
				}
			} catch (ParseException ex) {
				ex.printStackTrace();
			}
			restaurantDto.setQueryDate(queryDate);

			restaurantDto.getTables().stream().forEach(table -> {
				Integer reservedCount = selectedTableRepository.fetchReservedCount(table.getId(),
						restaurantDto.getQueryDate());
				if (reservedCount != null) {
					table.setAvaiableNoOfTables(table.getTotalNoOfTables() - reservedCount);
				} else {
					table.setAvaiableNoOfTables(table.getTotalNoOfTables());
				}
			});
			return restaurantDto;
		}
		return null;
	}

	@Override
	public List<RestaurantDto> searchRestaurant(String key) {
		List<Restaurant> results = restaurantRepo.search(key);
		if (results != null) {
			List<RestaurantDto> allDtos = new ArrayList<>();
			for (Restaurant restaurant : results) {
				restaurant.getTables();
				allDtos.add(RestaurantServiceMapper.mapRestaurant(restaurant));
			}
			return allDtos;
		}
		return null;
	}

}
