package pritam.demo.usermgmt;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class UserMangementServerDemoApplication {

	public static void main(String[] args) {
		SpringApplication.run(UserMangementServerDemoApplication.class, args);
	}

}
