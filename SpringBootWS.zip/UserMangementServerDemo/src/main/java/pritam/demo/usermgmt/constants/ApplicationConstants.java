package pritam.demo.usermgmt.constants;

public class ApplicationConstants {

	public static final String USERNAME = "username";
	public static final String PASSWORD = "password";
	public static final String GRANT_TYPE="grant_type";
	public static final String ACCESS_TOKEN = "access_token";

}
