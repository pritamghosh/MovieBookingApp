package pritam.demo.usermgmt.controller;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import pritam.demo.usermgmt.dto.UserRequest;
import pritam.demo.usermgmt.dto.LoginRequest;
import pritam.demo.usermgmt.dto.UpdatePasswordRequest;
import pritam.demo.usermgmt.dto.UserResponse;
import pritam.demo.usermgmt.service.UserManagementService;

@RestController
public class UserManagementController {

	@Autowired
	UserManagementService service;

	@GetMapping(value = "test")
	public String test() {
		return "usermgt";
	}

	@PostMapping("/login")
	public UserResponse login(@RequestBody LoginRequest request) {
		return service.login(request);
	}

	@PutMapping("/update/password")
	public boolean updatePassword(@RequestParam("access_token") String access_token,
			@RequestBody @Valid UpdatePasswordRequest request) {
		return service.updatePassword(request, access_token);
	}

	@PutMapping("/update/user")
	public UserResponse updateUser(@RequestParam("access_token") String access_token,
			@RequestBody @Valid UserRequest request) {
		return service.updateUser(request, access_token);
	}

	@PostMapping("/create/user")
	public boolean createUser(@RequestBody @Valid UserRequest request) {
		return service.createUser(request);
	}
}
