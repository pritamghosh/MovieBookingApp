package pritam.demo.usermgmt.dto;

public class LoginResponse extends UserResponse {
	TokenInfo tokenInfo;

	public final TokenInfo getTokenInfo() {
		return tokenInfo;
	}

	public final void setTokenInfo(TokenInfo tokenInfo) {
		this.tokenInfo = tokenInfo;
	}
}
