package pritam.demo.usermgmt.dto;

public class ResetPasswordRequest extends UserRequest {

}
