package pritam.demo.usermgmt.dto;

public class TokenInfo {
	private String access_token;
	private String refresh_token;
	private String token_type;
	private String scope;
	private int expires_in;

	public final String getAccess_token() {
		return access_token;
	}

	public final void setAccess_token(String access_token) {
		this.access_token = access_token;
	}

	public final String getRefresh_token() {
		return refresh_token;
	}

	public final void setRefresh_token(String refresh_token) {
		this.refresh_token = refresh_token;
	}

	public final String getToken_type() {
		return token_type;
	}

	public final void setToken_type(String token_type) {
		this.token_type = token_type;
	}

	public final String getScope() {
		return scope;
	}

	public final void setScope(String scope) {
		this.scope = scope;
	}

	public final int getExpires_in() {
		return expires_in;
	}

	public final void setExpires_in(int expires_in) {
		this.expires_in = expires_in;
	}

}
