package pritam.demo.usermgmt.dto;

/**
 * <pre>
 * <b>Description : </b>
 * CreateUserRequest.
 * 
 * @version $Revision: 1 $ $Date: Dec 20, 2017 1:03:54 PM $
 * @author $Author: pritam.ghosh $ 
 * </pre>
 */
public class UserRequest extends UserResponse {

private String password;
private String role;
public final String getPassword() {
	return password;
}
public final void setPassword(String password) {
	this.password = password;
}
public final String getRole() {
	return role;
}
public final void setRole(String role) {
	this.role = role;
} 




}
