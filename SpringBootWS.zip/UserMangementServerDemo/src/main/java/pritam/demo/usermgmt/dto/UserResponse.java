package pritam.demo.usermgmt.dto;

import java.util.List;

/**
 * <pre>
 * <b>Description : </b>
 * UserResponse.
 * 
 * &#64;version $Revision: 1 $ $Date: Dec 13, 2017 1:07:27 PM $
 * &#64;author $Author: pritam.ghosh $
 * </pre>
 */
public class UserResponse {
	private String name;
	private String email;
	private String contact;
	private String gender;
	private List<String> roles;
	private String username;

	private String address;

	public final String getAddress() {
		return address;
	}

	public final void setAddress(String address) {
		this.address = address;
	}

	public final String getName() {
		return name;
	}

	public final void setName(String name) {
        this.name = name;
    }

	public final String getEmail() {
		return email;
	}

	public final void setEmail(String email) {
		this.email = email;
	}

	public final String getContact() {
		return contact;
	}

	public final void setContact(String contact) {
		this.contact = contact;
	}

	public final String getGender() {
		return gender;
	}

	public final void setGender(String gender) {
		this.gender = gender;
	}

	public final List<String> getRoles() {
		return roles;
	}

	public final void setRoles(List<String> roles) {
		this.roles = roles;
	}

	public final String getUsername() {
		return username;
	}

	public final void setUsername(String username) {
		this.username = username;
	}

}
