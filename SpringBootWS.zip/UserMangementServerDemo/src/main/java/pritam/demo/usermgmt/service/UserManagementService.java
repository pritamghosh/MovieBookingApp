package pritam.demo.usermgmt.service;

import javax.validation.Valid;

import pritam.demo.usermgmt.dto.LoginRequest;
import pritam.demo.usermgmt.dto.LoginResponse;
import pritam.demo.usermgmt.dto.UpdatePasswordRequest;
import pritam.demo.usermgmt.dto.UserRequest;
import pritam.demo.usermgmt.dto.UserResponse;

public interface UserManagementService {

	LoginResponse login(LoginRequest request);

	boolean updatePassword(@Valid UpdatePasswordRequest request,String access_token);

	UserResponse updateUser(@Valid UserRequest request, String access_token);

	boolean createUser(@Valid UserRequest request);


}
