package pritam.demo.usermgmt.service.impl;

import java.net.URI;
import java.util.Date;

import javax.validation.Valid;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.CacheControl;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestClientException;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.util.UriComponentsBuilder;

import pritam.demo.usermgmt.constants.ApplicationConstants;
import pritam.demo.usermgmt.dto.LoginRequest;
import pritam.demo.usermgmt.dto.LoginResponse;
import pritam.demo.usermgmt.dto.TokenInfo;
import pritam.demo.usermgmt.dto.UpdatePasswordRequest;
import pritam.demo.usermgmt.dto.UserRequest;
import pritam.demo.usermgmt.dto.UserResponse;
import pritam.demo.usermgmt.service.UserManagementService;

@Service
public class UserManagementServiceImpl implements UserManagementService {

    private static final Logger LOGGER = LoggerFactory.getLogger(UserManagementServiceImpl.class);
	@Value("${app.client.id}")
	private String clientId;
	@Value("${app.url.access.token}")
	private String accessTokenUrl;
	@Value("${app.client.secret}")
	private String secret;
	@Value("${app.url.user.get}")
	private String getUserUrl;
	
	@Value("${app.url.password.update}")
	private String updatePasswordUrl;	
	@Value("${app.url.user.update}")
	private String updateUserUrl;
	@Value("${app.url.user.create}")
	private URI createUserUrl;

	@Override
	public LoginResponse login(LoginRequest request) {
		RestTemplate restTemplate = new RestTemplate();
		HttpHeaders headers = new HttpHeaders();
		headers.setBasicAuth(clientId, secret);
		headers.setContentType(MediaType.APPLICATION_JSON);
		headers.setCacheControl(CacheControl.noStore());
		headers.setDate(new Date().getTime());
		headers.setPragma("no-cache");
		HttpEntity<String> requestEntity = new HttpEntity<String>("parameters", headers);

		UriComponentsBuilder urlBuilder = UriComponentsBuilder.fromHttpUrl(accessTokenUrl)
				.queryParam(ApplicationConstants.USERNAME, request.getUsername())
				.queryParam(ApplicationConstants.GRANT_TYPE, ApplicationConstants.PASSWORD)
				.queryParam(ApplicationConstants.PASSWORD, request.getPassword());
		try {
			ResponseEntity<TokenInfo> tokenInfoResponse = restTemplate.exchange(urlBuilder.build().toUriString(),
					HttpMethod.POST, requestEntity, TokenInfo.class);
			TokenInfo tokenInfo = tokenInfoResponse.getBody();

			restTemplate = new RestTemplate();
			urlBuilder = UriComponentsBuilder.fromHttpUrl(getUserUrl).queryParam(ApplicationConstants.ACCESS_TOKEN,
					tokenInfo.getAccess_token());
			ResponseEntity<LoginResponse> result = restTemplate.exchange(urlBuilder.build().toUriString(), HttpMethod.GET,
					null, LoginResponse.class);
			LoginResponse response = result.getBody();
			response.setTokenInfo(tokenInfo);
			return response;
		} catch (RestClientException ex) {
			LOGGER.error(ex.getMessage(),ex);
			throw ex;
		}
	}

	@Override
	public boolean updatePassword(@Valid UpdatePasswordRequest request,String access_token) {
		RestTemplate restTemplate = new RestTemplate();
		UriComponentsBuilder urlBuilder =  UriComponentsBuilder.fromHttpUrl(updatePasswordUrl).queryParam(ApplicationConstants.ACCESS_TOKEN,
				access_token);
		HttpEntity<UpdatePasswordRequest> requestEntity = new HttpEntity<UpdatePasswordRequest>(request);
		ResponseEntity<Boolean> result = restTemplate.exchange(urlBuilder.build().toUriString(), HttpMethod.PUT, requestEntity, Boolean.class);

		return result.getBody();
	}

	@Override
	public UserResponse updateUser(@Valid UserRequest request, String access_token) {
		RestTemplate restTemplate = new RestTemplate();
		UriComponentsBuilder urlBuilder =  UriComponentsBuilder.fromHttpUrl(updateUserUrl).queryParam(ApplicationConstants.ACCESS_TOKEN,
				access_token);
		HttpEntity<UserRequest> requestEntity = new HttpEntity<UserRequest>(request);
		ResponseEntity<UserResponse> result = restTemplate.exchange(urlBuilder.build().toUriString(), HttpMethod.PUT, requestEntity, UserResponse.class);

		return result.getBody();
	}

	@Override
	public boolean createUser(@Valid UserRequest request) {
		RestTemplate restTemplate = new RestTemplate();
		HttpEntity<UserRequest> requestEntity = new HttpEntity<UserRequest>(request);
		ResponseEntity<Boolean> result = restTemplate.exchange(createUserUrl, HttpMethod.POST, requestEntity, Boolean.class);

		return result.getBody();
	}

}
